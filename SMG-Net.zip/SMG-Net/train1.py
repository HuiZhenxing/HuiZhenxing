import torch
from torch import nn
from torch.cuda.amp import autocast, GradScaler
from torch.utils.data import DataLoader
# from loader import *

from engine import *
import os
import sys
from dataset.npy_datasets import NPY_datasets

os.environ["CUDA_VISIBLE_DEVICES"] = "0"  # "0, 1, 2, 3"

from utils import *
from configs.config_setting import setting_config

import warnings

warnings.filterwarnings("ignore")


# torch.backends.cudnn.deterministic = True

import os
import sys
import argparse
import importlib.util

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

from utils import *
import warnings

warnings.filterwarnings("ignore")

# 从配置文件加载默认参数
def load_config(config_path):
    spec = importlib.util.spec_from_file_location("config", config_path)
    config = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(config)
    return config


# 解析命令行参数
def parse_args():
    parser = argparse.ArgumentParser(description="Training script")

    # 配置文件参数：现在默认指向 `configs/config_setting_CGNet_DySample_GSConvns_CBAM.py`
    parser.add_argument('--config', type=str, default='configs/config_setting.py', help='Path to the config file (Python script)')

    # 数据集参数：如果没有传递，使用配置文件中的默认值
    parser.add_argument('--dataset', type=str, help='Dataset name')

    # 训练轮数参数：如果没有传递，使用配置文件中的默认值
    parser.add_argument('--epochs', type=int, help='Number of epochs for training')
    parser.add_argument('--batch_size', type=int, help='Number of batch_size for training')

    parser.add_argument('--network', type=str, help='network')
    parser.add_argument('--M', type=int, help='M')
    parser.add_argument('--N', type=int, help='N')

    return parser.parse_args()


def main():
    # 解析命令行参数
    args = parse_args()

    # 打印命令行参数，确保解析工作正常
    print(f"Command line arguments: {args}")


    # 加载配置文件
    config = load_config(args.config)
    if args.network is not None:
        config.setting_config.network = args.network
        from datetime import datetime
        config.setting_config.work_dir = 'results/' + args.network + str(args.batch_size)+ '_' + args.dataset  + '_' + datetime.now().strftime('%A_%d_%B_%Y_%Hh_%Mm_%Ss') + '/'

    if args.M is not None:
        config.setting_config.M =   int(args.M )
        print(config.setting_config.M,'------------------------')
    if args.N is not None:
        config.setting_config.N = int(args.N )
        print(config.setting_config.N,'------------------------')

    # 覆盖配置文件中的数据集参数
    if args.dataset is not None:
        # 直接覆盖配置中的 dataset 设置，确保命令行优先
        config.setting_config.datasets = args.dataset

        print('config.setting_config.datasets ',config.setting_config.datasets )
        if args.dataset == 'ISIC2017':
            config.setting_config.data_path = './data/isic2017/'
        elif args.dataset == 'ISIC2018':
            config.setting_config.data_path = './data/isic2018/'
        elif args.dataset == 'PH2':
            config.setting_config.data_path = 'data/dataset_ph2/'
        else:
            raise ValueError("Unsupported dataset!")
    else:
        # 如果命令行没有传入 datasets，则使用默认设置
        print(f"Using default dataset from setting_config: {config.setting_config.datasets}")


    # 覆盖 epochs 参数，如果命令行没有传递，则使用配置文件中的默认值
    if args.epochs is not None:
        config.setting_config.epochs = args.epochs
    else:
        print(f"Using default epochs: {config.setting_config.epochs}")

    # 覆盖 batch_size 参数，如果命令行没有传递，则使用配置文件中的默认值
    if args.batch_size is not None:
        config.setting_config.batch_size = args.batch_size
    else:
        print(f"Using default epochs: {config.setting_config.batch_size}")

    # 输出确认
    print(f"Final config: dataset={config.setting_config.datasets}, data_path={config.setting_config.data_path}")
    print(f"epochs={config.setting_config.epochs}, batch_size={config.setting_config.batch_size}")

    # 继续调用训练流程
    train(config.setting_config)


def train(config):
    print('#----------Creating logger----------#')
    # sys.path.append(config.work_dir + '/')
    sys.path.append(config.work_dir + '/')

    log_dir = os.path.join(config.work_dir, 'log')
    print(log_dir,config.work_dir,'------------------------------------------')
    checkpoint_dir = os.path.join(config.work_dir, 'checkpoints')
    resume_model = os.path.join(checkpoint_dir, 'latest.pth')
    outputs = os.path.join(config.work_dir, 'outputs')
    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)
    if not os.path.exists(outputs):
        os.makedirs(outputs)

    global logger
    logger = get_logger('train', log_dir)

    log_config_info(config, logger)

    print('#----------GPU init----------#')
    set_seed(config.seed)
    gpu_ids = [0]  # [0, 1, 2, 3]
    torch.cuda.empty_cache()

    print('#----------Preparing dataset----------#')
    # train_dataset = NPY_datasets(path_Data=config.data_path, train=True)
    train_dataset = NPY_datasets(config.data_path, config, train=True)

    train_loader = DataLoader(train_dataset,
                              batch_size=config.batch_size,
                              shuffle=True,
                              pin_memory=True,
                              num_workers=config.num_workers)
    # val_dataset = NPY_datasets(path_Data=config.data_path, train=False)
    val_dataset = NPY_datasets(config.data_path, config, train=False)

    val_loader = DataLoader(val_dataset,
                            batch_size=1,
                            shuffle=False,
                            pin_memory=True,
                            num_workers=config.num_workers,
                            drop_last=True)
    # test_dataset = NPY_datasets(path_Data=config.data_path, train=False, Test=True)
    test_dataset = NPY_datasets(config.data_path, config, train=False)
    test_loader = DataLoader(test_dataset,
                             batch_size=1,
                             shuffle=False,
                             pin_memory=True,
                             num_workers=config.num_workers,
                             drop_last=True)

    print('#----------Prepareing Models----------#')
    model_cfg = config.model_config

    if config.network == 'SMGNet':
        from models.malunet import SMGNet
        model = SMGNet(num_classes = 1, input_channels = 3, c_list = [8, 16, 24, 32, 48, 64],
        split_att = 'fc', bridge = True)
    if config.network == 'A2FPN':
        from models.A2FPN import A2FPN
        model = A2FPN(3).cuda()
    if config.network == 'ABCNet':
        from models.ABCNet import ABCNet
        model = ABCNet(3,1).cuda()

    if config.network == 'AttU_Net':
        from models.Attention_UNet import AttU_Net
        model = AttU_Net(3,1).cuda()

    if config.network == 'DFANet':
        from models.DFANet import DFANet
        channel_cfg = [[8, 48, 96], [240, 144, 288], [240, 144, 288]]  # 根据您的DFANet模型定义
        model = DFANet(channel_cfg, decoder_channel=64, num_classes=1).cuda()

    if config.network == 'ENet':
        from models.ENet import ENet
        model = ENet(1).cuda()

    if config.network == 'SegNet':
        from models.SegNet import SegNet
        model = SegNet(1).cuda()
    if config.network == 'PSPNet':
        from models.PSPNet import PSPNet
        model = PSPNet(1).cuda()
    if config.network == 'MAResUNet':
        from models.MAResUNet import MAResUNet
        model = MAResUNet(3,1).cuda()
    if config.network == 'CMUNet':
        from models.CMUNet import CMUNet
        model = CMUNet(3,1).cuda()

    if config.network == 'CENet':
        from models.CENet import CE_Net_
        model = CE_Net_(num_channels=3,num_classes=1).cuda()

    if config.network == 'MACUNet':
        from models.MACUNet import MACUNet
        model = MACUNet(3,1).cuda()

    if config.network == 'SegFomer':
        from models.SegFormer import SegFomer
        model = SegFomer(3,1).cuda()

    if config.network == 'SwingUNet':
        from models.SwingUNet import SwingUNet
        model = SwingUNet(3,1).cuda()

    print('{}正在运行'.format(config.network))

    model = torch.nn.DataParallel(model.cuda(), device_ids=gpu_ids, output_device=gpu_ids[0])

    print('#----------Prepareing loss, opt, sch and amp----------#')
    criterion = config.criterion
    optimizer = get_optimizer(config, model)
    scheduler = get_scheduler(config, optimizer)
    scaler = GradScaler()

    print('#----------Set other params----------#')
    min_loss = 999
    start_epoch = 1
    min_epoch = 1

    if os.path.exists(resume_model):
        print('#----------Resume Model and Other params----------#')
        checkpoint = torch.load(resume_model, map_location=torch.device('cpu'))
        model.module.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        saved_epoch = checkpoint['epoch']
        start_epoch += saved_epoch
        min_loss, min_epoch, loss = checkpoint['min_loss'], checkpoint['min_epoch'], checkpoint['loss']

        log_info = f'resuming model from {resume_model}. resume_epoch: {saved_epoch}, min_loss: {min_loss:.4f}, min_epoch: {min_epoch}, loss: {loss:.4f}'
        logger.info(log_info)

    print('#----------Training----------#')
    for epoch in range(start_epoch, config.epochs + 1):

        torch.cuda.empty_cache()

        train_one_epoch(
            train_loader,
            model,
            criterion,
            optimizer,
            scheduler,
            epoch,
            logger,
            config,
            scaler=scaler
        )

        # 修改这里，以从 val_one_epoch 获取单独的损失值
        val_loss, metrics = val_one_epoch(
            val_loader,
            model,
            criterion,
            epoch,
            logger,
            config
        )

        # 现在隶属于 val_loss 的是一个标量损失值
        if val_loss < min_loss:
            torch.save(model.module.state_dict(), os.path.join(checkpoint_dir, 'best.pth'))
            min_loss = val_loss
            min_epoch = epoch

        torch.save(
            {
                'epoch': epoch,
                'min_loss': min_loss,
                'min_epoch': min_epoch,
                'loss': val_loss,  # 修改为 val_loss
                'model_state_dict': model.module.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
            }, os.path.join(checkpoint_dir, 'latest.pth'))

        # ... 省略后面部分代码


    if os.path.exists(os.path.join(checkpoint_dir, 'best.pth')):
        print('#----------Testing----------#')
        best_weight = torch.load(config.work_dir + 'checkpoints/best.pth', map_location=torch.device('cpu'))
        model.module.load_state_dict(best_weight)
        loss = test_one_epoch(
                val_loader,
                model,
                criterion,
                logger,
                config,
            )
        os.rename(
            os.path.join(checkpoint_dir, 'best.pth'),
            os.path.join(checkpoint_dir, f'best-epoch{min_epoch}-loss{min_loss:.4f}.pth')
        )


# if __name__ == '__main__':
#     config = setting_config
#     main(config)

if __name__ == '__main__':
    main()