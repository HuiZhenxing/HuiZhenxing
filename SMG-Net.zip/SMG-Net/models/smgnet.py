import torch
from torch import nn
import torch.nn.functional as F
import math


# from thop import profile

# ========================= 自定义基础模块 =========================

class EAblock(nn.Module):
    def __init__(self, channels):
        super(EAblock, self).__init__()
        self.conv1 = nn.Conv2d(channels, channels, 1)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)
        self.conv3 = nn.Conv2d(channels, channels, 5, padding=2)
        self.fuse = nn.Conv2d(channels * 3, channels, 1)

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)
        out = torch.cat([x1, x2, x3], dim=1)
        return self.fuse(out)


class DilatedGatedAttention(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DilatedGatedAttention, self).__init__()
        self.gate = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=2, dilation=2),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=1),
            nn.Sigmoid()
        )
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)

    def forward(self, x):
        g = self.gate(x)
        return self.conv(x) * g


class SC_Att_Bridge(nn.Module):
    def __init__(self, c_list, mode='fc'):
        super(SC_Att_Bridge, self).__init__()
        self.compress = nn.ModuleList([
            nn.Conv2d(c_list[0], c_list[0], 1),  # t1
            nn.Conv2d(c_list[1], c_list[1], 1),  # t2
            nn.Conv2d(c_list[2], c_list[2], 1),  # t3
            nn.Conv2d(c_list[2], c_list[2], 1),  # t4, 使用c_list[2]替代c_list[3]
            nn.Conv2d(c_list[3], c_list[3], 1)  # t5
        ])
        self.gates = nn.ModuleList([
            nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Conv2d(c_list[0], c_list[0] // 4, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(c_list[0] // 4, c_list[0], 1),
                nn.Sigmoid()
            ),
            nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Conv2d(c_list[1], c_list[1] // 4, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(c_list[1] // 4, c_list[1], 1),
                nn.Sigmoid()
            ),
            nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Conv2d(c_list[2], c_list[2] // 4, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(c_list[2] // 4, c_list[2], 1),
                nn.Sigmoid()
            ),
            nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Conv2d(c_list[2], c_list[2] // 4, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(c_list[2] // 4, c_list[2], 1),
                nn.Sigmoid()
            ),
            nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Conv2d(c_list[3], c_list[3] // 4, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(c_list[3] // 4, c_list[3], 1),
                nn.Sigmoid()
            )
        ])

    def forward(self, t1, t2, t3, t4, t5):
        t = [t1, t2, t3, t4, t5]
        out = []
        for i in range(5):
            f = self.compress[i](t[i])
            w = self.gates[i](f)
            out.append(f * w)
        return out


# ========================= 自定义功能模块 =========================

class MRFE(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(MRFE, self).__init__()
        self.main_conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=2, padding=1)
        self.pool_conv = nn.Sequential(
            nn.AvgPool2d(2),
            nn.Conv2d(in_channels, out_channels, kernel_size=1)
        )
        self.slice_conv = nn.Conv2d(in_channels * 4, out_channels, kernel_size=1)
        self.gated_conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.Sigmoid()
        )
        self.fusion = nn.Sequential(
            nn.Conv2d(out_channels * 4, out_channels, kernel_size=1),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        f1 = self.main_conv(x)
        f2 = self.pool_conv(x)
        B, C, H, W = x.shape
        slices = [x[:, :, i::2, j::2] for i in range(2) for j in range(2)]
        f3 = torch.cat(slices, dim=1)
        f3 = self.slice_conv(f3)

        f3 = F.interpolate(f3, size=f1.shape[2:], mode='bilinear', align_corners=False)

        f4 = self.gated_conv(x)
        f4 = F.interpolate(f4, size=f1.shape[2:], mode='bilinear', align_corners=False)

        f = torch.cat([f1, f2, f3, f4], dim=1)
        return self.fusion(f)


class SACP(nn.Module):
    def __init__(self, in_channels):
        super(SACP, self).__init__()
        self.fusion = nn.Sequential(
            nn.Conv2d(in_channels * 3, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        B, C, H, W = x.shape
        h = torch.mean(x, dim=3, keepdim=True).expand(-1, -1, H, W)
        v = torch.mean(x, dim=2, keepdim=True).expand(-1, -1, H, W)
        d = torch.mean(torch.stack([x[:, :, i, i] for i in range(min(H, W))], dim=2), dim=2, keepdim=True).unsqueeze(
            -1).expand(-1, -1, H, W)
        weight = self.fusion(torch.cat([h, v, d], dim=1))
        return x * weight


class GSSFusion(nn.Module):
    def __init__(self, low_channels, high_channels):
        super(GSSFusion, self).__init__()
        self.attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(high_channels, low_channels // 4, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(low_channels // 4, low_channels, kernel_size=1),
            nn.Sigmoid()
        )
        self.spatial = nn.Conv2d(low_channels + high_channels, 1, kernel_size=7, padding=3)
        self.fuse = nn.Sequential(
            nn.Conv2d(low_channels * 2 + high_channels, low_channels, kernel_size=1),
            nn.GroupNorm(8, low_channels)  # 使用GroupNorm替代BatchNorm2d
        )

    def forward(self, fh, fl):
        # 确保fh和fl具有相同的空间尺寸
        if fh.shape[2:] != fl.shape[2:]:
            fh = F.interpolate(fh, size=fl.shape[2:], mode='bilinear', align_corners=True)

        wc = self.attn(fh)
        fl_weighted = fl * wc
        ws = torch.sigmoid(self.spatial(torch.cat([fl, fh], dim=1)))
        fl_weighted = fl_weighted * ws
        concat = torch.cat([fl_weighted, fl, fh], dim=1)
        return self.fuse(concat)


# ========================= SMGNet 模型主体 =========================

class SMGNet(nn.Module):
    def __init__(self, num_classes=1, input_channels=3, c_list=[8, 16, 24, 32, 48, 64], split_att='fc', bridge=True):
        super().__init__()
        self.bridge = bridge

        self.encoder1 = MRFE(input_channels, c_list[0])
        self.encoder2 = MRFE(c_list[0], c_list[1])
        self.encoder3 = MRFE(c_list[1], c_list[2])
        self.encoder4 = nn.Sequential(EAblock(c_list[2]), SACP(c_list[2]))
        self.encoder5 = nn.Sequential(
            nn.Conv2d(c_list[2], c_list[3], kernel_size=1),  # 先将通道数从24转为32
            EAblock(c_list[3]),
            SACP(c_list[3])
        )
        self.encoder6 = nn.Sequential(
            nn.Conv2d(c_list[3], c_list[4], kernel_size=1),  # 从32通道转为48通道
            EAblock(c_list[4]),
            SACP(c_list[4])
        )

        if bridge:
            self.scab = SC_Att_Bridge(c_list, split_att)

        self.decoder1 = nn.Sequential(GSSFusion(c_list[4], c_list[4]), EAblock(c_list[4]))
        self.decoder2 = nn.Sequential(GSSFusion(c_list[3], c_list[4]), EAblock(c_list[3]))
        self.decoder3 = nn.Sequential(GSSFusion(c_list[2], c_list[3]), EAblock(c_list[2]))
        self.decoder4 = nn.Sequential(nn.Conv2d(c_list[2], c_list[1], 3, padding=1))
        self.decoder5 = nn.Sequential(nn.Conv2d(c_list[1], c_list[0], 3, padding=1))

        # 使用 BatchNorm2d 替代 GroupNorm 进行测试
        self.ebn1 = nn.BatchNorm2d(c_list[0])
        self.ebn2 = nn.BatchNorm2d(c_list[1])
        self.ebn3 = nn.BatchNorm2d(c_list[2])
        self.ebn4 = nn.BatchNorm2d(c_list[2])
        self.ebn5 = nn.BatchNorm2d(c_list[3])
        # 对于小的特征图，使用GroupNorm替代BatchNorm
        self.dbn1 = nn.GroupNorm(8, c_list[4])  # 将通道分成8组进行归一化
        self.dbn2 = nn.BatchNorm2d(c_list[3])
        self.dbn3 = nn.BatchNorm2d(c_list[2])
        self.dbn4 = nn.BatchNorm2d(c_list[1])
        self.dbn5 = nn.BatchNorm2d(c_list[0])

        self.final = nn.Conv2d(c_list[0], num_classes, kernel_size=1)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        out = self.encoder1(x)
        out = F.gelu(F.max_pool2d(self.ebn1(out), 2, 2));
        t1 = out
        out = self.encoder2(out)
        out = F.gelu(F.max_pool2d(self.ebn2(out), 2, 2));
        t2 = out
        out = self.encoder3(out)
        out = F.gelu(F.max_pool2d(self.ebn3(out), 2, 2));
        t3 = out
        out = self.encoder4(out)
        out = F.gelu(F.max_pool2d(self.ebn4(out), 2, 2));
        t4 = out
        out = self.encoder5(out)
        out = F.gelu(F.max_pool2d(self.ebn5(out), 2, 2));
        t5 = out

        if self.bridge:
            t1, t2, t3, t4, t5 = self.scab(t1, t2, t3, t4, t5)

        out = F.gelu(self.encoder6(out))

        # 添加通道数调整层，将t5的通道数增加到48
        t5_adjusted = F.pad(t5, [0, 0, 0, 0, 0, 16])  # 在通道维度上填充0

        # 修复GSSFusion的使用方式，需要提供两个参数
        out5 = self.decoder1[0](out, t5_adjusted)  # GSSFusion部分
        out5 = self.decoder1[1](out5)  # EAblock部分
        out5 = F.gelu(self.dbn1(out5))
        out5 = torch.add(out5, t5_adjusted)

        # 将t4的通道数从24增加到32，以匹配decoder2的要求
        t4_adjusted = F.pad(t4, [0, 0, 0, 0, 0, 8])  # 在通道维度上填充0

        # 修复GSSFusion的使用方式
        out4 = self.decoder2[0](out5, t4_adjusted)  # GSSFusion部分
        out4 = self.decoder2[1](out4)  # EAblock部分
        out4 = F.gelu(self.dbn2(out4))  # 去掉上采样
        # 确保out4和t4_adjusted形状匹配
        out4 = torch.add(out4, t4_adjusted)
        # 现在再上采样
        out4 = F.interpolate(out4, scale_factor=2, mode='bilinear', align_corners=True)

        # 修复GSSFusion的使用方式
        out3 = self.decoder3[0](out4, t3)  # GSSFusion部分
        out3 = self.decoder3[1](out3)  # EAblock部分
        out3 = F.gelu(self.dbn3(out3))  # 去掉上采样
        # 确保out3和t3形状匹配
        out3 = torch.add(out3, t3)
        # 现在再上采样
        out3 = F.interpolate(out3, scale_factor=2, mode='bilinear', align_corners=True)

        out2 = F.gelu(self.dbn4(self.decoder4(out3)))  # 去掉上采样
        # 确保out2和t2形状匹配
        # 调整out2的大小以匹配t2
        out2 = F.interpolate(out2, size=t2.shape[2:], mode='bilinear', align_corners=True)
        out2 = torch.add(out2, t2)

        out1 = F.gelu(self.dbn5(self.decoder5(out2)))  # 去掉上采样
        # 确保out1和t1形状匹配
        # 调整out1的大小以匹配t1
        out1 = F.interpolate(out1, size=t1.shape[2:], mode='bilinear', align_corners=True)
        out1 = torch.add(out1, t1)

        out0 = self.final(out1)

        # 增加两次上采样操作，确保输出尺寸与输入一致
        # 第一次上采样
        out0 = F.interpolate(out0, scale_factor=2, mode='bilinear', align_corners=True)
        # 第二次上采样，确保与原始输入尺寸一致
        out0 = F.interpolate(out0, size=(x.size(2), x.size(3)), mode='bilinear', align_corners=True)

        return torch.sigmoid(out0)


# ========================= 运行测试 =========================

if __name__ == "__main__":
    input = torch.randn(1, 3, 256, 256)
    model = SMGNet()
    output = model(input)

    # flops, params = profile(model, inputs=(input,))
    # print('flops', flops / 1e9)
    # print('params', params / 1e6)
    print("Total params: %.2fM" % (sum(p.numel() for p in model.parameters()) / 1e6))
    print('输入格式{}，输出格式{}'.format(input.size(), output.size()))
