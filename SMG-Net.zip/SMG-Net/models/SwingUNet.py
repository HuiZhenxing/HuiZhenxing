import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.checkpoint as checkpoint
from typing import Tuple


# ---------- 小工具 ----------
def pair(x):
    return (x, x) if isinstance(x, int) else x


class DropPath(nn.Module):
    def __init__(self, drop_prob: float = 0.0):
        super().__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        if self.drop_prob == 0.0 or not self.training:
            return x
        keep_prob = 1.0 - self.drop_prob
        shape = (x.size(0),) + (1,) * (x.ndim - 1)
        random_tensor = keep_prob + torch.rand(shape, device=x.device, dtype=x.dtype)
        random_tensor.floor_()
        return x.div(keep_prob) * random_tensor


# ---------- MLP ----------
class Mlp(nn.Module):
    def __init__(self, in_ch, hid_ch=None, out_ch=None, act=nn.GELU, drop=0.0):
        super().__init__()
        out_ch = out_ch or in_ch
        hid_ch = hid_ch or in_ch
        self.fc1 = nn.Linear(in_ch, hid_ch)
        self.act = act()
        self.fc2 = nn.Linear(hid_ch, out_ch)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


# ---------- 窗口工具 ----------
def window_partition(x, ws):
    B, H, W, C = x.shape
    x = x.view(B, H // ws, ws, W // ws, ws, C)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous()
    return x.view(-1, ws, ws, C)


def window_reverse(x, ws, H, W):
    B = int(x.size(0) / (H * W / ws / ws))
    x = x.view(B, H // ws, W // ws, ws, ws, -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous()
    return x.view(B, H, W, -1)


# ---------- 窗口注意力 ----------
class WindowAttention(nn.Module):
    def __init__(self, dim, ws, heads, qkv_bias=True, qk_scale=None, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        self.dim = dim
        self.ws = ws
        self.heads = heads
        self.head_dim = dim // heads
        self.scale = qk_scale or self.head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        # relative pos bias
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * ws - 1) * (2 * ws - 1), heads))
        coords = torch.stack(torch.meshgrid(torch.arange(ws), torch.arange(ws))).flatten(1)
        relative_coords = coords[:, :, None] - coords[:, None, :]
        relative_coords[0] += ws - 1
        relative_coords[1] += ws - 1
        relative_coords[0] *= 2 * ws - 1
        rel_idx = relative_coords.sum(0).view(-1)
        self.register_buffer("rel_idx", rel_idx)
        nn.init.trunc_normal_(self.relative_position_bias_table, std=0.02)

    def forward(self, x, mask=None):
        B_, N, C = x.shape
        qkv = self.qkv(x).reshape(B_, N, 3, self.heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]

        attn = (q @ k.transpose(-2, -1)) * self.scale
        bias = self.relative_position_bias_table[self.rel_idx].view(
            self.ws * self.ws, self.ws * self.ws, -1).permute(2, 0, 1).contiguous()
        attn = attn + bias.unsqueeze(0)

        if mask is not None:
            nW = mask.size(0)
            attn = attn.view(B_ // nW, nW, self.heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.heads, N, N)
        attn = F.softmax(attn, dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B_, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


# ---------- Swin Block ----------
class SwinBlock(nn.Module):
    def __init__(self, dim, res, heads, ws=7, shift=0,
                 mlp_ratio=4.0, drop=0.0, attn_drop=0.0, drop_path=0.0):
        super().__init__()
        self.dim = dim
        self.res = res
        self.ws = ws
        self.shift = shift
        if min(res) <= ws:
            self.shift = 0
            self.ws = min(res)

        self.norm1 = nn.LayerNorm(dim)
        self.attn = WindowAttention(dim, self.ws, heads, attn_drop=attn_drop, proj_drop=drop)
        self.drop_path = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = Mlp(dim, int(dim * mlp_ratio), drop=drop)

        if self.shift > 0:
            H, W = res
            img_mask = torch.zeros(1, H, W, 1)
            h_slices = (slice(0, -ws), slice(-ws, -shift), slice(-shift, None))
            w_slices = (slice(0, -ws), slice(-ws, -shift), slice(-shift, None))
            cnt = 0
            for h in h_slices:
                for w in w_slices:
                    img_mask[:, h, w, :] = cnt
                    cnt += 1
            mask_windows = window_partition(img_mask, ws).view(-1, ws * ws)
            attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)
            attn_mask = attn_mask.masked_fill(attn_mask != 0, float(-100.0)).masked_fill(attn_mask == 0, 0.0)
            self.register_buffer("attn_mask", attn_mask)
        else:
            self.register_buffer("attn_mask", None)

    def forward(self, x):
        H, W = self.res
        B, L, C = x.shape
        assert L == H * W

        shortcut = x
        x = self.norm1(x).view(B, H, W, C)

        if self.shift > 0:
            x = torch.roll(x, shifts=(-self.shift, -self.shift), dims=(1, 2))
        x_windows = window_partition(x, self.ws)
        x_windows = x_windows.view(-1, self.ws * self.ws, C)
        attn_windows = self.attn(x_windows, mask=self.attn_mask)
        attn_windows = attn_windows.view(-1, self.ws, self.ws, C)
        x = window_reverse(attn_windows, self.ws, H, W)
        if self.shift > 0:
            x = torch.roll(x, shifts=(self.shift, self.shift), dims=(1, 2))
        x = x.view(B, H * W, C)

        x = shortcut + self.drop_path(x)
        x = x + self.drop_path(self.mlp(self.norm2(x)))
        return x


# ---------- 上下采样 ----------
class DownMerge(nn.Module):
    def __init__(self, res, dim):
        super().__init__()
        self.res = res
        self.dim = dim
        self.norm = nn.LayerNorm(4 * dim)
        self.reduction = nn.Linear(4 * dim, 2 * dim, bias=False)

    def forward(self, x):
        H, W = self.res
        B, L, C = x.shape
        assert L == H * W and H % 2 == 0 and W % 2 == 0
        x = x.view(B, H, W, C)

        x0 = x[:, 0::2, 0::2, :]
        x1 = x[:, 1::2, 0::2, :]
        x2 = x[:, 0::2, 1::2, :]
        x3 = x[:, 1::2, 1::2, :]
        x = torch.cat([x0, x1, x2, x3], -1).view(B, -1, 4 * C)
        x = self.norm(x)
        x = self.reduction(x)
        return x


class UpExpand(nn.Module):
    def __init__(self, res, dim, scale=2):
        super().__init__()
        self.res = res
        self.expand = nn.Linear(dim, 2 * dim, bias=False) if scale == 2 else nn.Identity()
        self.norm = nn.LayerNorm(dim // scale)

    def forward(self, x):
        H, W = self.res
        x = self.expand(x)
        B, L, C = x.shape
        assert L == H * W
        x = x.view(B, H, W, C)
        x = x.view(B, H, W, 2, 2, C // 4).permute(0, 1, 3, 2, 4, 5).contiguous()
        x = x.view(B, H * 2, W * 2, C // 4).view(B, -1, C // 4)
        x = self.norm(x)
        return x


class FinalUp4x(nn.Module):
    def __init__(self, res, dim):
        super().__init__()
        self.res = res
        self.expand = nn.Linear(dim, 16 * dim, bias=False)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        H, W = self.res
        x = self.expand(x)
        B, L, C = x.shape
        assert L == H * W
        x = x.view(B, H, W, 16, C // 16)
        x = x.view(B, H, W, 4, 4, C).permute(0, 1, 3, 2, 4, 5).contiguous()
        x = x.view(B, H * 4, W * 4, C).view(B, -1, C)
        x = self.norm(x)
        return x


# ---------- 编码/解码阶段 ----------
class EncoderStage(nn.Module):
    def __init__(self, dim, res, depth, heads, ws=7,
                 mlp_ratio=4.0, drop=0.0, attn_drop=0.0, drop_path=None, downsample=None):
        super().__init__()
        self.blocks = nn.ModuleList([
            SwinBlock(dim=dim, res=res, heads=heads, ws=ws,
                      shift=0 if i % 2 == 0 else ws // 2,
                      mlp_ratio=mlp_ratio,
                      drop=drop, attn_drop=attn_drop,
                      drop_path=drop_path[i] if isinstance(drop_path, list) else drop_path)
            for i in range(depth)])
        self.down = downsample(res, dim) if downsample else None

    def forward(self, x):
        for blk in self.blocks:
            x = checkpoint.checkpoint(blk, x) if hasattr(blk, 'use_checkpoint') else blk(x)
        if self.down:
            x = self.down(x)
        return x


class DecoderStage(nn.Module):
    def __init__(self, dim, res, depth, heads, ws=7,
                 mlp_ratio=4.0, drop=0.0, attn_drop=0.0, drop_path=None, upsample=None):
        super().__init__()
        self.blocks = nn.ModuleList([
            SwinBlock(dim=dim, res=res, heads=heads, ws=ws,
                      shift=0 if i % 2 == 0 else ws // 2,
                      mlp_ratio=mlp_ratio,
                      drop=drop, attn_drop=attn_drop,
                      drop_path=drop_path[i] if isinstance(drop_path, list) else drop_path)
            for i in range(depth)])
        self.up = upsample(res, dim) if upsample else None

    def forward(self, x):
        for blk in self.blocks:
            x = checkpoint.checkpoint(blk, x) if hasattr(blk, 'use_checkpoint') else blk(x)
        if self.up:
            x = self.up(x)
        return x


# ---------- Patch Embedding ----------
class PatchEmbed(nn.Module):
    def __init__(self, img_size=224, patch_size=4, in_ch=3, embed_dim=96):
        super().__init__()
        img_size = pair(img_size)
        patch_size = pair(patch_size)
        self.patches_res = [img_size[0] // patch_size[0], img_size[1] // patch_size[1]]
        self.proj = nn.Conv2d(in_ch, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):
        x = self.proj(x).flatten(2).transpose(1, 2)
        return self.norm(x)


# ---------- SwingUNet ----------
class SwingUNet(nn.Module):
    def __init__(self,
                 img_size=224,
                 patch_size=4,
                 in_ch=3,
                 num_classes=1,
                 embed_dim=96,
                 depths=[2, 2, 2, 2],
                 depths_up=[1, 2, 2, 2],
                 heads=[3, 6, 12, 24],
                 ws=7,
                 mlp_ratio=4.0,
                 drop=0.0,
                 attn_drop=0.0,
                 drop_path=0.1):
        super().__init__()
        self.num_layers = len(depths)
        self.embed_dim = embed_dim
        self.num_classes = num_classes

        # patch_embed
        self.patch_embed = PatchEmbed(img_size, patch_size, in_ch, embed_dim)
        res = self.patch_embed.patches_res

        # stochastic depth
        dpr = [x.item() for x in torch.linspace(0, drop_path, sum(depths))]
        cur = 0

        # encoder
        self.encoder = nn.ModuleList()
        for i in range(self.num_layers):
            self.encoder.append(
                EncoderStage(dim=int(embed_dim * 2 ** i),
                             res=(res[0] // (2 ** i), res[1] // (2 ** i)),
                             depth=depths[i],
                             heads=heads[i],
                             ws=ws,
                             mlp_ratio=mlp_ratio,
                             drop=drop,
                             attn_drop=attn_drop,
                             drop_path=dpr[cur:cur + depths[i]],
                             downsample=DownMerge if i < self.num_layers - 1 else None)
            )
            cur += depths[i]

        # decoder
        self.decoder = nn.ModuleList()
        for i in range(self.num_layers):
            idx = self.num_layers - 1 - i
            concat_dim = 2 * int(embed_dim * 2 ** idx) if i > 0 else int(embed_dim * 2 ** idx)
            self.decoder.append(
                DecoderStage(dim=int(embed_dim * 2 ** idx),
                             res=(res[0] // (2 ** idx), res[1] // (2 ** idx)),
                             depth=depths_up[i],
                             heads=heads[idx],
                             ws=ws,
                             mlp_ratio=mlp_ratio,
                             drop=drop,
                             attn_drop=attn_drop,
                             drop_path=dpr[sum(depths) - 1: sum(depths) - 1 - depths_up[i]: -1],
                             upsample=UpExpand if i < self.num_layers - 1 else None)
            )

        # final
        self.final_up = FinalUp4x(res, embed_dim)
        self.head = nn.Conv2d(embed_dim, num_classes, 1)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.trunc_normal_(m.weight, std=0.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        x = self.patch_embed(x)
        skips = []
        for layer in self.encoder:
            skips.append(x)
            x = layer(x)

        skips.reverse()
        for i, layer in enumerate(self.decoder):
            if i > 0:
                x = torch.cat([x, skips[i]], -1)
            x = layer(x)

        x = self.final_up(x)
        B, L, C = x.shape
        H, W = self.patch_embed.patches_res
        x = x.view(B, 4 * H, 4 * W, C).permute(0, 3, 1, 2)
        x = self.head(x)
        return x


# ---------- test ----------
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = SwingUNet(img_size=224, num_classes=1).to(device)
    x = torch.randn(1, 3, 224, 224).to(device)

    with torch.no_grad():
        y = model(x)
    print("Input :", x.shape)
    print("Output:", y.shape)

    try:
        from thop import profile
        flops, params = profile(model, inputs=(x,))
        print(f"FLOPs : {flops / 1e9:.2f}G")
        print(f"Params: {params / 1e6:.2f}M")
    except ImportError:
        print("thop not found, skipping FLOPs.")

        # 延迟 & 吞吐
        latency, fps = benchmark(model, x, warmup=args.warmup, repeat=args.repeat)
        print(f"Avg latency   : {latency:.2f} ms")
        print(f"Throughput    : {fps:.1f} samples/s")

        # 显存占用
        print(f"Memory usage  : {mem_usage(device):.1f} MB")

        # 清理
        del model, x, y
        gc.collect()
        torch.cuda.empty_cache() if device.type == "cuda" else None