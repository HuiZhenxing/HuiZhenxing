import os
import random
import numpy as np
import torch
from PIL import Image
import torchvision.transforms as transforms
from torchvision.transforms import ToPILImage
import warnings
import importlib.util
import argparse
import logging

# 导入模型和自定义模块
from models.malunet import MALUNet
from models.ea_block import EAblock
from models.dilated_gated_attention import DilatedGatedAttention
from models.sc_att_bridge import SC_Att_Bridge

# 设置环境变量和忽略警告
os.environ["CUDA_VISIBLE_DEVICES"] = "0"  # 指定使用的GPU
warnings.filterwarnings("ignore")


# 设置随机种子的函数
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# 获取日志记录器的函数
def get_logger(name, log_dir):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    file_handler = logging.FileHandler(os.path.join(log_dir, 'train.log'))
    console_handler = logging.StreamHandler()

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


# 加载配置文件的函数
def load_config(config_path):
    spec = importlib.util.spec_from_file_location("config", config_path)
    config = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(config)
    return config


def parse_args():
    parser = argparse.ArgumentParser(description="Training and Inference script")
    parser.add_argument('--config', type=str, default='configs/config_setting.py',
                        help='Path to the config file (Python script)')
    parser.add_argument('--dataset', type=str, help='Dataset name')
    parser.add_argument('--epochs', type=int, help='Number of epochs for training')
    parser.add_argument('--batch_size', type=int, help='Batch size for training')
    parser.add_argument('--network', type=str, help='Network architecture')
    parser.add_argument('--M', type=int, help='Parameter M')
    parser.add_argument('--N', type=int, help='Parameter N')

    return parser.parse_args()


def main():
    args = parse_args()
    print(f"Command line arguments: {args}")

    config = load_config(args.config)
    if args.network is not None:
        config.setting_config.network = args.network
        from datetime import datetime
        config.setting_config.work_dir = 'results/' + args.network + str(
            args.batch_size) + '_' + args.dataset + '_' + datetime.now().strftime('%A_%d_%B_%Y_%Hh_%Mm_%Ss') + '/'

    if args.M is not None:
        config.setting_config.M = int(args.M)
    if args.N is not None:
        config.setting_config.N = int(args.N)

    if args.dataset is not None:
        config.setting_config.datasets = args.dataset
        if args.dataset == 'ISIC2017':
            config.setting_config.data_path = 'data/dataset_isic17/'
        elif args.dataset == 'ISIC2018':
            config.setting_config.data_path = 'data/dataset_isic18/'
        elif args.dataset == 'PH2':
            config.setting_config.data_path = 'data/dataset_ph2/'
        else:
            raise ValueError("Unsupported dataset!")

    if args.epochs is not None:
        config.setting_config.epochs = args.epochs

    if args.batch_size is not None:
        config.setting_config.batch_size = args.batch_size

    print(f"Final config: dataset={config.setting_config.datasets}, data_path={config.setting_config.data_path}")
    print(f"epochs={config.setting_config.epochs}, batch_size={config.setting_config.batch_size}")

    infer(config.setting_config)


def infer(config):
    input_folder = r"D:\Thesis experiment\MALUNet-main\data\isic\val\images"  # 输入文件夹路径
    output_folder = r"D:\Thesis experiment\MALUNet-main\data\isic\val\malunet"  # 输出文件夹路径

    print('#----------Creating logger----------#')
    log_dir = os.path.join(config.work_dir, 'log')
    checkpoint_dir = os.path.join(config.work_dir, 'checkpoints')

    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)

    global logger
    logger = get_logger('inference', log_dir)

    print('#----------GPU init----------#')
    set_seed(config.seed)  # 设置随机种子
    gpu_ids = [0]  # 指定使用的GPU
    torch.cuda.empty_cache()

    model_cfg = config.model_config
    transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.ToTensor(),
    ])

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for image_file in os.listdir(input_folder):
        if image_file.endswith(('.png', '.jpg', '.jpeg')):
            image_path = os.path.join(input_folder, image_file)
            image = Image.open(image_path).convert('RGB')

            input_tensor = transform(image).unsqueeze(0).cuda()

            model = MALUNet(num_classes=model_cfg['num_classes'],
                            input_channels=model_cfg['input_channels'],
                            c_list=model_cfg['c_list'],
                            split_att=model_cfg['split_att'],
                            bridge=model_cfg['bridge'])
            model = torch.nn.DataParallel(model.cuda(), device_ids=gpu_ids, output_device=gpu_ids[0])

            # 加载权重文件
            try:
                best_weight_path = 'results/迁移学习/malunet_isic18_Thursday_06_February_2025_11h_57m_45s/checkpoints/best-epoch141-loss0.1364.pth'
                best_weight = torch.load(best_weight_path, map_location=torch.device('cuda'))
                model.module.load_state_dict(best_weight, strict=False)  # 使用 strict=False 忽略不匹配的键
                logger.info(f"成功加载权重文件: {best_weight_path}")
            except Exception as e:
                logger.error(f"加载权重文件失败: {e}")
                raise

            model.eval()  # 设置为评估模式

            with torch.no_grad():
                output = model(input_tensor)
                output_image = torch.sigmoid(output)  # 使用 sigmoid 激活函数
                output_image_rgb = output_image[0, :3, :, :]

                to_pil = ToPILImage()
                output_image_pil = to_pil(output_image_rgb)
                output_image_pil.save(os.path.join(output_folder, f'output_{image_file}'))

                output_image_bw = output_image_pil.convert('L')
                output_image_bw.save(os.path.join(output_folder, f'outputL_{image_file}'))

                logger.info(f'处理完成: {image_file}, 输出保存为: {output_folder}')

if __name__ == '__main__':
    main()