import os
import random
import numpy as np
import torch
from PIL import Image
import torchvision.transforms as transforms
from torchvision.transforms import ToPILImage
import warnings
import importlib.util
import argparse
import logging

# 换成 Segformer
from transformers import SegformerImageProcessor, SegformerForSemanticSegmentation

# 环境 & 警告
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
warnings.filterwarnings("ignore")


# ---------- 通用工具 ----------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_logger(name, log_dir):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    os.makedirs(log_dir, exist_ok=True)
    fh = logging.FileHandler(os.path.join(log_dir, 'train.log'))
    ch = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger


def load_config(config_path):
    spec = importlib.util.spec_from_file_location("config", config_path)
    config = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(config)
    return config


def parse_args():
    parser = argparse.ArgumentParser(description="Training and Inference script")
    parser.add_argument('--config', type=str, default='configs/config_setting.py')
    parser.add_argument('--dataset', type=str, help='Dataset name')
    parser.add_argument('--epochs', type=int, help='Number of epochs for training')
    parser.add_argument('--batch_size', type=int, help='Batch size for training')
    parser.add_argument('--network', type=str, help='Network architecture')
    parser.add_argument('--M', type=int, help='Parameter M')
    parser.add_argument('--N', type=int, help='Parameter N')
    return parser.parse_args()


# --------------------------------------------------
def main():
    args = parse_args()
    print(f"Command line arguments: {args}")

    config = load_config(args.config)

    # 动态覆盖配置（同 one.py）
    if args.network is not None:
        config.setting_config.network = args.network
        from datetime import datetime
        config.setting_config.work_dir = 'results/' + args.network + str(
            args.batch_size) + '_' + args.dataset + '_' + datetime.now().strftime('%A_%d_%B_%Y_%Hh_%Mm_%Ss') + '/'

    if args.M is not None:
        config.setting_config.M = int(args.M)
    if args.N is not None:
        config.setting_config.N = int(args.N)

    if args.dataset is not None:
        config.setting_config.datasets = args.dataset
        if args.dataset == 'ISIC2017':
            config.setting_config.data_path = 'data/dataset_isic17/'
        elif args.dataset == 'ISIC2018':
            config.setting_config.data_path = 'data/dataset_isic18/'
        elif args.dataset == 'PH2':
            config.setting_config.data_path = 'data/dataset_ph2/'
        else:
            raise ValueError("Unsupported dataset!")

    if args.epochs is not None:
        config.setting_config.epochs = args.epochs
    if args.batch_size is not None:
        config.setting_config.batch_size = args.batch_size

    print(f"Final config: dataset={config.setting_config.datasets}, data_path={config.setting_config.data_path}")
    print(f"epochs={config.setting_config.epochs}, batch_size={config.setting_config.batch_size}")

    infer_segformer(config.setting_config)


# --------------------------------------------------
def infer_segformer(config):
    input_folder = r"D:\Thesis experiment\MALUNet-main\data\isic\val\images"
    output_folder = r"D:\Thesis experiment\MALUNet-main\data\isic\val\segformer"
    os.makedirs(output_folder, exist_ok=True)

    print('#----------Creating logger----------#')
    log_dir = os.path.join(config.work_dir, 'log')
    os.makedirs(log_dir, exist_ok=True)
    global logger
    logger = get_logger('inference', log_dir)

    print('#----------GPU init----------#')
    set_seed(config.seed)
    gpu_ids = [0]
    torch.cuda.empty_cache()

    # --- Segformer 专用 processor & 模型 ---
    processor = SegformerImageProcessor(reduce_labels=False,
                                        size={"height": 256, "width": 256},
                                        keep_aspect_ratio=False)
    model = SegformerForSemanticSegmentation.from_pretrained(
        "nvidia/segformer-b0-finetuned-ade-512-512",  # 可换 b1/b2/b3
        num_labels=1,  # 二分类
        ignore_mismatched_sizes=True
    )
    model = torch.nn.DataParallel(model.cuda(), device_ids=gpu_ids, output_device=gpu_ids[0])

    # 载入微调权重（若有）
    try:
        best_weight_path = 'results/segformer_isic18_XXXX/checkpoints/best.pth'  # 按需修改
        best_weight = torch.load(best_weight_path, map_location="cuda")
        model.module.load_state_dict(best_weight, strict=False)
        logger.info(f"成功加载权重文件: {best_weight_path}")
    except Exception as e:
        logger.warning(f"未加载权重，使用预训练参数: {e}")

    model.eval()

    # 与 MALUNet 保持一致的后处理
    to_pil = ToPILImage()

    transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.ToTensor(),  # 仅用于 Tensor 化，归一化由 processor 完成
    ])

    for image_file in os.listdir(input_folder):
        if image_file.lower().endswith(('.png', '.jpg', '.jpeg')):
            image_path = os.path.join(input_folder, image_file)
            image = Image.open(image_path).convert('RGB')

            # processor 自动归一化
            inputs = processor(images=image, return_tensors="pt").to(model.device)

            with torch.no_grad():
                logits = model(**inputs).logits          # [B, 1, H/4, W/4]
                upsampled = torch.nn.functional.interpolate(
                    logits,
                    size=image.size[::-1],               # PIL (W,H)
                    mode="bilinear",
                    align_corners=False
                )
                pred = torch.sigmoid(upsampled)          # [B,1,H,W]

            # 保存彩色 overlay
            overlay = pred[0, :3].expand(3, -1, -1)    # 3×H×W
            output_image_pil = to_pil(overlay.cpu())
            output_image_pil.save(os.path.join(output_folder, f'output_{image_file}'))

            # 保存二值 mask
            mask = (pred[0, 0] > 0.5).float()
            mask_pil = to_pil(mask.cpu())
            mask_pil.save(os.path.join(output_folder, f'outputL_{image_file}'))

            logger.info(f'处理完成: {image_file}')


if __name__ == '__main__':
    main()