import random
import numpy as np
from torchvision.transforms import ToPILImage
import warnings
import importlib.util
import torch
import os
from PIL import Image
import torchvision.transforms as transforms
import argparse
import logging

# 设置随机种子的函数
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# 获取日志记录器的函数
def get_logger(name, log_dir):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    file_handler = logging.FileHandler(os.path.join(log_dir, 'predict.log'))
    console_handler = logging.StreamHandler()

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger

# 加载配置文件的函数
def load_config(config_path):
    spec = importlib.util.spec_from_file_location("config", config_path)
    config = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(config)
    return config

# 解析命令行参数的函数
def parse_args():
    parser = argparse.ArgumentParser(description="Prediction script for MAResUNet model")
    parser.add_argument('--config', type=str, default='configs/config_setting.py',
                        help='Path to the config file (Python script)')
    parser.add_argument('--dataset', type=str, help='Dataset name')
    parser.add_argument('--batch_size', type=int, help='Number of batch_size for prediction')
    parser.add_argument('--network', type=str, help='Network name')
    return parser.parse_args()

def main():
    args = parse_args()
    print(f"Command line arguments: {args}")

    config = load_config(args.config)
    if args.network is not None:
        config.setting_config.network = args.network
        from datetime import datetime
        config.setting_config.work_dir = 'results/' + args.network + str(
            args.batch_size) + '_' + args.dataset + '_' + datetime.now().strftime('%A_%d_%B_%Y_%Hh_%Mm_%Ss') + '/'

    if args.dataset is not None:
        config.setting_config.datasets = args.dataset
        if args.dataset == 'ISIC2017':
            config.setting_config.data_path = 'data/dataset_isic17/'
        elif args.dataset == 'ISIC2018':
            config.setting_config.data_path = 'data/dataset_isic18/'
        elif args.dataset == 'PH2':
            config.setting_config.data_path = 'data/dataset_ph2/'
        else:
            raise ValueError("Unsupported dataset!")

    if args.batch_size is not None:
        config.setting_config.batch_size = args.batch_size

    print(f"Final config: dataset={config.setting_config.datasets}, data_path={config.setting_config.data_path}")
    print(f"batch_size={config.setting_config.batch_size}")

    predict(config.setting_config)

def predict(config):
    input_folder = r"D:\Thesis experiment\MALUNet-main\data\isic2018\val\images"
    output_folder = r"D:\Thesis experiment\MALUNet-main\data\isic2018\maresunet"


    print('#----------Creating logger----------#')
    log_dir = os.path.join(config.work_dir, 'log')
    checkpoint_dir = os.path.join(config.work_dir, 'checkpoints')

    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)

    global logger
    logger = get_logger('predict', log_dir)

    print('#----------GPU init----------#')
    set_seed(config.seed)
    gpu_ids = [0]  # [0, 1, 2, 3]
    torch.cuda.empty_cache()

    from models.MAResUNet import MAResUNet

    transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.ToTensor(),
    ])

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for image_file in os.listdir(input_folder):
        if image_file.endswith(('.png', '.jpg', '.jpeg')):
            image_path = os.path.join(input_folder, image_file)
            image = Image.open(image_path).convert('RGB')

            input_tensor = transform(image).unsqueeze(0).cuda()

            # 创建MAResUNet模型实例，并传入num_classes参数
            model = MAResUNet(num_channels=3, num_classes=1).cuda()  # 假设num_classes=1，根据你的实际情况修改
            # 加载预训练权重
            state_dict = torch.load(
                r'D:\Thesis experiment\MALUNet-main\results\MAResUNet4\checkpoints\best-epoch1-loss1.2552.pth',
                map_location=torch.device('cpu'))

            # 移除 'module.' 前缀
            new_state_dict = {k.replace('module.', ''): v for k, v in state_dict.items()}
            # 加载权重
            model.load_state_dict(new_state_dict)

            # 包装模型在 DataParallel 中
            model = torch.nn.DataParallel(model, device_ids=gpu_ids, output_device=gpu_ids[0])

            output = model(input_tensor)
            output_image = output[0, 0, :, :].cpu().detach().numpy()  # 取第一个通道

            # 将输出转换为二值图像
            output_image = (output_image > 0.5).astype(np.uint8) * 255

            to_pil = ToPILImage()
            output_image_pil = to_pil(output_image)
            output_image_pil.save(os.path.join(output_folder, f'output_{image_file}'))

            logger.info(f'Processed: {image_file}, Output saved as: {output_folder}')

if __name__ == '__main__':
    main()