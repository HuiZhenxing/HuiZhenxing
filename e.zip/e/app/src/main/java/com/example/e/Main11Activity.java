package com.example.e;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/*
主界面的java代码
 */
public class Main11Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);
        zhuCe();
        login();
    }
    /*
    注册信息
     */
    private void zhuCe() {
        Button btnRegister = (Button)findViewById(R.id.btn_zhuce);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main11Activity.this,Register.class);
                startActivity(intent);//跳转到注册界面
            }
        });
    }
    /*
    登录
     */
    private void login(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared",MODE_PRIVATE);
        final String userName = sharedPreferences.getString("username","");
        final String passWord = sharedPreferences.getString("password","");

        Button btnLogin = (Button)findViewById(R.id.btn_login);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText username = (EditText)findViewById(R.id.edit_username);
                EditText password = (EditText)findViewById(R.id.edit_password);

                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals(userName)){
                    if(pass.equals(passWord)){
                        Intent intent0 = new Intent(Main11Activity.this,Okey.class);
                        startActivity(intent0);
                    }else{
                        AlertDialog.Builder builder = new AlertDialog.Builder(Main11Activity.this);
                        builder.setMessage("密码错误，请重新输入！");
                        builder.setPositiveButton("OK",null);
                        builder.create().show();
                    }
                }else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(Main11Activity.this);
                    builder.setMessage("没有用户信息，请注册！");
                    builder.setPositiveButton("OK",null);
                    builder.create().show();
                }
            }
        });
    }
}
